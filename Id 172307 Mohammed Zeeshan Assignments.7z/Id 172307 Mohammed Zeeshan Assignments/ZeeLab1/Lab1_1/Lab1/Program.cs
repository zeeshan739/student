﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] e = new Employee[3];
            for(int i=0;i<=2;i++)
            {
                e[i] = new Employee();
                Console.WriteLine("Enter the Employee details");
                Console.WriteLine("Enter the Employee ID");
                e[i].EmpId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Employee Name");
                e[i].EmpName = Console.ReadLine();
                Console.WriteLine("Enter the Employee Address");
                e[i].Address = Console.ReadLine();
                Console.WriteLine("Enter the Employee City");
                e[i].City = Console.ReadLine();
                Console.WriteLine("Enter the Employee Department");
                e[i].Department = Console.ReadLine();
                Console.WriteLine("Enter the Employee Salary");
                e[i].Salary = Convert.ToDouble(Console.ReadLine());
            }
           List<Employee> employee = new List<Employee>(2);
            for(int i=0;i<=2;i++)
            {
                Console.WriteLine("{0},{1}", e[i].EmpName, e[i].Salary);
                //Console.WriteLine($"Employee name : {e[i].EmpName}");
                //Console.WriteLine($"Employee salary : {e[i].Salary}");
            }
            Console.ReadKey();
        }
    }
}
