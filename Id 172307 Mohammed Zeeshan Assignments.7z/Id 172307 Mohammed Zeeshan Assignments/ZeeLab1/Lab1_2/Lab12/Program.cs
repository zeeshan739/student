﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab12
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            double num3, num4;
            int op;
            int sum, prod, sub, mul, div, mod;
            double sumd, prodd, subd, muld, divd, modd;
            Calculate c1 = new Calculate();
            Console.WriteLine("Enter 2 int values");
            num1 = Convert.ToInt32(Console.ReadLine());
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter 2 double values");
            num3 = Convert.ToDouble(Console.ReadLine());
            num4 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the operation to be performed");
            op = Convert.ToInt32(Console.ReadLine());
            switch(op)
            {
                case 1:
                    sum = Calculate.Add(num1, num2);
                    sumd = Calculate.Add(num3, num4);
                    Console.WriteLine($"{num1}+{num2}={sum}");
                    Console.WriteLine($"{num3}+{num4}={sumd}");
                    break;
                case 2:
                    sub = Calculate.Sub(num1, num2);
                    subd = Calculate.Sub(num3, num4);
                    Console.WriteLine($"{num1}-{num2}={sub}");
                    Console.WriteLine($"{num3}-{num4}={subd}");
                    break;
                case 3:
                    mul = Calculate.Multiply(num1, num2);
                    muld = Calculate.Mul(num3, num4);
                    Console.WriteLine($"{num1}*{num2}={mul}");
                    Console.WriteLine($"{num3}+{num4}={muld}");
                    break;
                case 4:
                    div = Calculate.Divide(num1, num2);
                    divd = Calculate.Div(num3, num4);
                    Console.WriteLine($"{num1}/{num2}={div}");
                    Console.WriteLine($"{num3}/{num4}={divd}");
                    break;
                case 5:
                    mod = Calculate.Modulus(num1, num2);
                    modd = Calculate.Mod(num3, num4);
                    Console.WriteLine($"{num1}%{num2}={mod}");
                    Console.WriteLine($"{num3}%{num4}={modd}");
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;

            }
            Console.ReadKey();

        }
    }
}
