﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Participant
{
    public class Participant
    {
        private int empId;
        private string name;
        private static string companyName;
        private int foundationMarks;
        private int webBasicMarks;
        private int dotNetMarks;
        private int totalMarks =300;
        private int obtainedMarks;
        private double percentage;
        //Properities
        public int EmpId { get; set; }
        public string Name { get; set; }
        public string CompanyName { get; set; }
        public int FoundationMarks
        {
            get {
                return foundationMarks;
                }
            set
            {
                if ((value > 0) && (value < 100))
                {
                    foundationMarks = value;
                }
                else
                {
                    foundationMarks = 0;
                    throw new InValidFoundationMarksException("Marks can't be greater than 100.");
                }
            }
         }
        public int WebBasicMarks
        {
            get
            {
                return foundationMarks;
            }
            set
            {
                if ((value > 0) && (value < 100))
                {
                    webBasicMarks = value;
                }
                else
                {
                    webBasicMarks = 0;
                }
            }
        }
        public int DotNetMarks
        {
            get
            {
                return dotNetMarks;
            }
            set
            {
                if ((value > 0) && (value < 100))
                {
                    dotNetMarks = value;
                }
                else
                {
                    dotNetMarks = 0;
                }
            }
        }
        public int TotalMarks { get;set; }
                              
        public int ObtainedMarks { get { return obtainedMarks; }
                                   set { obtainedMarks = foundationMarks + dotNetMarks + webBasicMarks; }
                                 }
        public double Percentage { get { return percentage; }
                                   set { percentage = (obtainedMarks / totalMarks) * 100; }
                                 }

        //Constructors
        public Participant()
        {
            Console.WriteLine("from Default constructor");
        }
        public Participant(int foundationMarks,int webBasicMarks,int dotNetMarks)
        {
            this.foundationMarks = foundationMarks;
            this.dotNetMarks = dotNetMarks;
            this.webBasicMarks = webBasicMarks;
        }
        static Participant()
        {
            companyName = "Corporate University";
        }
        public void CalculateObtainedMarks()
        {
             obtainedMarks = FoundationMarks + DotNetMarks + WebBasicMarks;
            Console.WriteLine("Total obtained marks are: " + obtainedMarks);
        }
        public void CalculatePercentage()
        {
            percentage = (obtainedMarks*100) / (totalMarks);
            Console.WriteLine("Percentage is: " + percentage);
        }
        public void DisplayPercentage(double percentage)
        {
            Console.WriteLine("percentage is :" + percentage);
        }
        
    }
    public class InValidFoundationMarksException : ApplicationException
    {
        public InValidFoundationMarksException()
            : base()
        {

        }
        public InValidFoundationMarksException(string message)
            : base(message)
        {

        }
    }
}
