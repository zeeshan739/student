﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab34
{
    class Program
    {
        static void Main(string[] args)
        {
            SupplierTest st = new SupplierTest();
            Console.WriteLine("Enter the Supplier Details");
            Console.WriteLine("Enter the supplier ID:");
            st.SupplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the supplier Name:");
            st.SupplierName = Console.ReadLine();
            Console.WriteLine("Enter the city:");
            st.City = Console.ReadLine();
            Console.WriteLine("Enter the supplier phonenumber:");
            st.PhoneNo = Console.ReadLine();
            Console.WriteLine("Enter the supplier email:");
            st.Email = Console.ReadLine();
            
            Console.WriteLine(st.DisplayDetails(st.SupplierID,st.SupplierName,st.City,st.PhoneNo,st.Email));
            Console.ReadKey();
        }
    }
}
