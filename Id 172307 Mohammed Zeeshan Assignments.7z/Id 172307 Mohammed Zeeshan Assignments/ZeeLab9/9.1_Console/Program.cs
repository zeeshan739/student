﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._1_Console
{
    class Program
    {
        static Dictionary<string, string> dictionary = new Dictionary<string, string>();
        static void Main(string[] args)
        {
            AddMethod();
            Display();
            Edit();
            Remove();
            Console.ReadLine();
        }

        static void AddMethod()
        {
            try
            {
                dictionary.Add("zee", "ajith");

                dictionary.Add("abhilash", "dinesh");

                dictionary.Add("saiteja", "sunny");

                dictionary.Add("naveen", "saikiran");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        static void Display()
        {
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Edit()
        {
            dictionary["suri"] = "surendra";
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Remove()
        {
            dictionary.Remove("naveen");
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

    }
}
