﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9._1_Console
{
    class Program
    {
        static Dictionary<string, string> dictionary = new Dictionary<string, string>();
        static void Main(string[] args)
        {
            AddMethod();
            Display();
            Edit();
            Remove();
            Console.ReadLine();
        }

        static void AddMethod()
        {
            try
            {
                dictionary.Add("suri", "ravi");

                dictionary.Add("gandhi", "dhinesh");

                dictionary.Add("pavan", "kumar");

                dictionary.Add("naveen", "kumar");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


        static void Display()
        {
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Edit()
        {
            dictionary["suri"] = "surendra";
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

        static void Remove()
        {
            dictionary.Remove("pavan");
            foreach (var obj in dictionary)
            {
                Console.WriteLine(obj);
            }
        }

    }
}
