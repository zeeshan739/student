﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidLab
{
    public class Employee
    {
        private int employeeId;
        private string empName;

        public int EmployeeId { get => employeeId; set => employeeId = value; }
        public string EmpName { get => empName; set => empName = value; }

        public static bool AddEmployee(Employee emp)
        {
            Console.WriteLine("Employee Details Added");
            return true;
        }

    }

    public abstract class Employee1
    {
        public virtual string GetProjectDetails(int EmployeeID)
        {
            return "Base Project Details:";
        }
        public virtual string GetEmployeeDetails(int EmployeeID)
        {
            return "Base Employee Details";
        }
    }

    //public interface IEmployee
    //{
    //    string GetEmployeeDetails(int employeeId);
    //}

    //public interface IProject
    //{
    //    string GetProjectDetails(int employeeId);
    //}

    public class PermanentEmployee : Employee1
    {
        public override string GetProjectDetails(int EmployeeID)
        {
            return "Child Project Details:";
        }
        public override string GetEmployeeDetails(int EmployeeID)
        {
            return "Child Employee Details";
        }
    }
    public class ContractEmployee : IEmployee
    {
        public string GetProjectDetails(int EmployeeID)
        {
            return "Child Project Details:";
        }
        public string GetEmployeeDetails(int EmployeeID)
        {
            throw new NotImplementedException();
        }
    }

    public class IReportGeneration
    {
        public string ReportType { get; set; }
        public virtual void GenerateReport()
        {
            //if (ReportType == "CRS")
            //{
            //    Console.WriteLine("Report is in  CRS Format");
            //}
            //if (ReportType == "PDF")
            //{
            //    Console.WriteLine("Report is in  PDF Format");
            //}
        }
    }
    public class CrystalReport : IReportGeneration
    {
        public override void GenerateReport()
        {
            Console.WriteLine("Report is in CRS Format");
        }
    }
    public class PDFReport : IReportGeneration
    {
        public override void GenerateReport()
        {
            Console.WriteLine("Report is in PDF Format");
        }
    }
    public interface IEmployee
    {
        string GetEmployeeDetails(int employeeId);
    }

    public interface IProject
    {
        string GetProjectDetails(int employeeId);
    }
    public interface IAddOperation
    {
        bool AddEmployeeDetails();
    }
    public interface IGetOperation
    {
        bool ShowEmployeeDetails(int employeeId);
    }
    public class AddOperation : IAddOperation
    {
        public bool AddEmployeeDetails()
        {
            Console.WriteLine("Employee Details Added");
            return true;
        }
    }
    public class getOperation : IGetOperation
    {
        public bool ShowEmployeeDetails(int employeeId)
        {
            Console.WriteLine("Employee details displayed");
            return true;
        }
    }
}
