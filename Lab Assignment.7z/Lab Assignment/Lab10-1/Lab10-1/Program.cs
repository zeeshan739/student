﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_1
{
    delegate int AODelegate(int n1,int n2);
    class ArthemeticOperations
    {
        public static int Add(int n1,int n2)
        {
            return n1 + n2;
        }
        public static int Sub(int n1, int n2)
        {
            return n1 - n2;
        }
        public static int Mul(int n1, int n2)
        {
            return n1 * n2;
        }
        public static int Div(int n1, int n2)
        {
            return n1 / n2;
        }
        public static int Max(int n1, int n2)
        {
            if(n1>n2)
            {
                return n1;
            }
            else
            {
                return n2;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Enter the numbers:");
            Console.WriteLine("Enter the number1");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number 2");
            n2 = Convert.ToInt32(Console.ReadLine());
            AODelegate d1 = new AODelegate(ArthemeticOperations.Add);
            Console.WriteLine(d1(n1, n2));
             d1+= new AODelegate(ArthemeticOperations.Sub);
            Console.WriteLine(d1(n1, n2));
            d1 += new AODelegate(ArthemeticOperations.Mul);
            Console.WriteLine(d1(n1, n2));
            d1 += new AODelegate(ArthemeticOperations.Div);
            Console.WriteLine(d1(n1, n2));
            d1 += new AODelegate(ArthemeticOperations.Max);
            Console.WriteLine(d1(n1, n2));
            Console.ReadKey();


        }
    }
}
