﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab41
{
    class PermanentEmployee : Employee
    {
        public double PF=1000.0,salary;
        public override double GetSalary(double salary)
        {
            return salary - PF;
        }
    }
}
