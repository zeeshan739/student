﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._1Console
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = null;
            Console.WriteLine("enter filename to read:");
            string fname = Console.ReadLine();
            try
            {
                sr = new StreamReader(fname + ".txt");
                Console.WriteLine("contents of a file:\n");
                string str = sr.ReadToEnd();
                Console.WriteLine(str);
                sr.Close();
            }

            catch (FileNotFoundException)
            {
                Console.WriteLine("file not found");
            }
            Console.ReadLine();
        }
    }    
}
