﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab32
{
    class Bird
    {
        public string Name;
        public double Maxheight;
        public double Atheight;
        public Bird()
        {
            this.Name = "Mountain Eagle";
            this.Maxheight = 500;
            this.Atheight = 450;
        }
        public Bird(string birdname, double max_ht) //Overloaded Constructor  
        {
            this.Name = "Another Bird";
            this.Maxheight = 0;
        }
        public void fly()
        {
            Console.WriteLine($"{Name} is flying at altitude {Maxheight}");
        }

        public void fly(double AtHeight)
        {
            if (AtHeight <= this.Maxheight)
            {
                Console.WriteLine($"{Name} flying at {(Atheight.ToString())}");
            }
            else
            {
                Console.WriteLine($"{Name} cannot fly at height");
            }
        }


    }

}
