﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab32
{
    class Program
    {
        static void Main(string[] args)
        {
            Bird b = new Bird("Eagle", double.Parse("200"));
            b.fly();
            b.fly(double.Parse("300"));
            Bird b1 = new Bird();
            b1.fly();
            b1.fly(double.Parse("500"));
            Console.ReadKey();

        }
    }
}
