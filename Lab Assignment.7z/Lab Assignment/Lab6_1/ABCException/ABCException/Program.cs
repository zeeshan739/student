﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCException
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter number of Customer:");
            int n = Convert.ToInt32(Console.ReadLine());
            Customer[] c = new Customer[n];
            for (int i = 0; i < n; i++)
            {
                
                
                Console.WriteLine("Enter Customer Details:");
                Console.WriteLine("Enter Customer ID");
                int CustomerId= Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Customer Name:");
                string CustomerName = Console.ReadLine();
                Console.WriteLine("Enter Customer Address:");
                string Address1 = Console.ReadLine();
                Console.WriteLine("Enter Customer city:");
                string City1 = Console.ReadLine();
                Console.WriteLine("Enter Customer Phone Number:");
               long Phone1 = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Enter the Customer Credit:");
                double CreditLimit1 = Convert.ToDouble(Console.ReadLine());
                try
                {
                    if (CreditLimit1 >=50000 )
                    {
                        throw (new InvalidCreditLimitException("Your CreditLimit is Above 50000"));

                    }
                    else
                    {
                        Console.WriteLine("CreditLimit is below 50000");
                    }

                }
                catch (InvalidCreditLimitException ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
