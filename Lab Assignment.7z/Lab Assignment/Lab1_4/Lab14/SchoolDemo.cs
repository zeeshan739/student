﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab14
{
    class SchoolDemo
    {
        private int rollNumber;
        private int age;
        private string studentName;
        private char gender;
        private DateTime dob;
        private string address;
        private double percentage;

        public int RollNumber { get => rollNumber; set => rollNumber = value; }
        public int Age { get => age; set => age = value; }
        public string StudentName { get => studentName; set => studentName = value; }
        public char Gender { get => gender; set => gender = value; }
        public DateTime Dob { get => dob; set => dob = value; }
        public string Address { get => address; set => address = value; }
        public double Percentage { get => percentage; set => percentage = value; }
    }
}
