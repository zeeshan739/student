﻿using SMSEntities;
using SMSExceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace SMSDAL
{
    /// <summary>
    /// To create the methods for performing operations on Student Entity
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    public class StudentDAL
    {
        static List<Student> studentList = new List<Student>();

        /// <summary>
        /// Function for inserting data into the list
        /// </summary>
        /// <param name="newstudent"></param>
        /// <returns>boolean value if user is added or not</returns>
        public bool AddStudentDAL(Student newstudent)
        {
            bool isStudentAdded = false;
            try
            {
                studentList.Add(newstudent);
                SerializeStudentDAL();
                isStudentAdded = true;
            }

            catch (StudentExcption)
            {
                throw;
            }
            return isStudentAdded;
        }
        /// <summary>
        /// Function for displaying the data from the student List
        /// </summary>
        /// <returns>List of students</returns>
        public List<Student> DisplayStudentDAL()
        {
            return DeserializeStudentDAL();
        }
        /// <summary>
        /// Function for serializing student List
        /// </summary>
        /// <returns>List of students</returns>
        public static void SerializeStudentDAL()
        {
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("StudentList.ser", FileMode.Create, FileAccess.Write);
                BinaryFormatter Formatter = new BinaryFormatter();
                Formatter.Serialize(fStream, studentList);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
        }

        public static List<Student> DeserializeStudentDAL()
        {
            List<Student> deserializedData = null;
            FileStream fStream = null;
            try
            {
                fStream = new FileStream("StudentList.ser", FileMode.Open, FileAccess.Read);
                BinaryFormatter Formatter = new BinaryFormatter();
                deserializedData = (List<Student>)Formatter.Deserialize(fStream);
            }
            catch (IOException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                fStream.Close();
            }
            return deserializedData;
        }

        public Student SearchStudentDAL(int studentId)
        {
            Student searchedStudent;

            try
            {
                searchedStudent = studentList.Find(student => student.StudentId == studentId);

            }
            catch (StudentExcption) { throw; }
            return searchedStudent;

        }

        public Student SearchStudentBLL(int studentId)
        {
            Student searchedStudent = null;
            try
            {
                StudentDAL studentDAL = new StudentDAL();
                searchedStudent = studentDAL.SearchStudentDAL(studentId);
            }
            catch (StudentExcption ex) { throw ex; }
            return searchedStudent;
        }
    } 

}