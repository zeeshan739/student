﻿using SMSDAL;
using SMSEntities;
using SMSExceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSBLL
{
    /// <summary>
    /// To create the Validation method and to invoke the operations from DAL
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    public class StudentBLL
    {
        static List<Student> sList = new List<Student>();

        public bool AddStudentBL(Student student)
        {
            bool isAdded = false;
            try
            {
                StudentDAL studentOperations = new StudentDAL();
                if (ValidateStudent(student))
                {
                    isAdded = studentOperations.AddStudentDAL(student);
                }
                else
                {
                    throw new StudentExcption("Validation Failed!!!Employee details could not be added");
                }
                if (isAdded == false)
                {
                    throw new StudentExcption("Student Details not Added");
                }
            }
            catch (StudentExcption e)
            {
                throw e;
            }
            return isAdded;
        }

        public List<Student> DisplayStudentBL()
        {
            StudentDAL studentOperations = new StudentDAL();
            try
            {
                sList = studentOperations.DisplayStudentDAL();
                if (sList.Count <= 0)
                {
                    throw new StudentExcption("No Records Found!!!");

                }
            }
            catch (StudentExcption e)
            {
                throw e;
            }

            return sList;
        }

        private static bool ValidateStudent(Student student)
        {
            bool validstudent = true;
            StringBuilder message = new StringBuilder();
            if (student.StudentId <= 0 || student.StudentId > 60)
            {
                message.Append(Environment.NewLine + "Invalid Student Id");
                validstudent = false;
            }
            if (student.StudentName==null || student.StudentName==string.Empty)
            {
                message.Append(Environment.NewLine + "Student Namecan not be blank");
                validstudent = false;
            }
            if (validstudent == false)
            {
                throw new StudentExcption(message.ToString());
            }
            return validstudent;
        }

        public Student SearchStudentBLL(int studentId)
        {
            Student searchedStudent = null;
            try
            {
                StudentDAL studentDAL = new StudentDAL();
                searchedStudent = studentDAL.SearchStudentDAL(studentId);
                if (searchedStudent == null) throw new StudentExcption("Student not found");

            }
            catch (StudentExcption Exception) { throw Exception; }
            return searchedStudent;
        }
    }
}
