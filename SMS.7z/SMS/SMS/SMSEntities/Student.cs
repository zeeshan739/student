﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSEntities
{
    /// <summary>
    /// To create the methods for performing operations on StudentEntity
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    [Serializable]
    public class Student
    {
        public int StudentId { get; set; }

        public string StudentName { get; set; }

        public long StudentPhoneNo { get; set; }

        public string StudentEmail { get; set; }

        public string StudentDept { get; set; }

        public Grade StudentGrade { get; set; }

    }

    /// <summary>
    /// Grade Enumeration, Values can be A,B,C,D
    /// </summary>
    public enum Grade
    {
        A, B, C, D
    }
}
