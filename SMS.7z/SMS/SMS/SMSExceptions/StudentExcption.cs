﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSExceptions
{
    /// <summary>
    /// Exception Class to catch the Exceptions occuring in Student Management System(SMS)
    /// Author:CG
    /// DOC:23rd Aug 2018
    /// </summary>
    public class StudentExcption : ApplicationException
    {
        //Default Constructor , that inherits the base constructor
        public StudentExcption() : base() { }

        // Parameterized constructor for passing the Error/Exception Message
        public StudentExcption(string Message) :
            base(Message)
        { }

    }
}
