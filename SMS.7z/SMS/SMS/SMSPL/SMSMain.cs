﻿using SMSBLL;
using SMSEntities;
using SMSExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMSPL
{
    /// <summary>
    /// Console Application to Manage the Student Information
    /// Author: CG
    /// DOC: 23rd Aug 2018
    /// </summary>
    class SMSMain
    {
        public static void AddStudentPL()
        {
            try
            {
                Student objStudent = new Student();
                Console.WriteLine("Enter the Student ID :");
                bool chkid;
                int sid;
                //Use TryParse to chk if the entered value is parseable or not
                chkid = Int32.TryParse(Console.ReadLine(), out sid);
                //If the Parsing fails, throw the Exception
                if (chkid == false)
                {
                    throw new StudentExcption("Invalid Entry");
                }
                // If the Parsing is successful, store the StudentId into the Entity object
                else
                {
                    objStudent.StudentId = sid;
                }
                Console.WriteLine("Enter Student Name:");
                objStudent.StudentName = Console.ReadLine();
                Console.WriteLine("Enter the Grade:");
                objStudent.StudentGrade = (Grade)Enum.Parse(typeof(Grade), Console.ReadLine());

                StudentBLL bllobj = new StudentBLL();
                
                if (bllobj.AddStudentBL(objStudent) == false)
                {
                    throw new StudentExcption("Student Record could not be added");

                }
                else
                {
                    Console.WriteLine("Student Details Added Successfully");
                }
            }

            catch (StudentExcption Exception)
            {
                Console.WriteLine("Error occurred " + Exception.Message);
            }
        }
        public static void DisplayStudentPL()
        {
            try
            {
                StudentBLL bllobj = new StudentBLL();                
                List<Student> sList = new List<Student>();
                sList = bllobj.DisplayStudentBL();
                Console.WriteLine("Student Details");
                Console.WriteLine("=================");
                foreach (Student s in sList)
                {
                    Console.WriteLine("Student Id :{0}\t Student Name :{1} \t Student Grade :{2}", s.StudentId, s.StudentName, s.StudentGrade);

                }

            }
            catch (StudentExcption e)
            {
                Console.WriteLine(e.Message);
            }

        }
        static void Main(string[] args)
        {
            byte choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Choice:");
                bool chkChoice;

                chkChoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!chkChoice) { Console.WriteLine("Invalid Input "); }
                switch (choice)
                {
                    case 1:
                        AddStudentPL();
                        break;
                    case 2:
                        DisplayStudentPL();
                        break;
                    case 3:
                        SearchStudentPL();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != 0);

        }

        private static void SearchStudentPL()
        {
            Student searchedStudent = null;
            try
            {
                Console.WriteLine("Enter Student Id to be searched:");
                int studentId = Int32.Parse(Console.ReadLine());
                StudentBLL studentBLL = new StudentBLL();

                searchedStudent = studentBLL.SearchStudentBLL(studentId);
                if (searchedStudent != null)
                {
                    Console.WriteLine("Searched Student Details:");
                    Console.WriteLine("Student Id: {0}", searchedStudent.StudentId);
                    Console.WriteLine("Student Name: {0}", searchedStudent.StudentName);
                    Console.WriteLine("Student Grade: {0}", searchedStudent.StudentGrade);
                }
            }
            catch (StudentExcption Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine("============================================");
            Console.WriteLine("Student Management System (SMS)");
            Console.WriteLine("Press 1 To Add New Student");
            Console.WriteLine("Press 2 To Display All Students");
            Console.WriteLine("Press 3 To Search Student");
            Console.WriteLine("Press 0 To Exit");
            Console.WriteLine("============================================");

        }
    }
}
